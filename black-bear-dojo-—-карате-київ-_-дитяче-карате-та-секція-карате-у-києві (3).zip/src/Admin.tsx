import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Settings, Users, MessageSquare, LogOut, Save, Image as ImageIcon, Plus, Trash2, MapPin, Clock } from 'lucide-react';

export const LoginPage = () => {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ login: login.trim(), password: password.trim() })
    });
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem('admin_token', data.token);
      navigate('/admin');
    } else {
      setError('Неправильний логін або пароль');
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="max-w-md w-full bg-zinc-900 p-8 rounded-2xl border border-white/10">
        <h2 className="text-2xl font-bold text-white text-center mb-6">Вхід для адміністратора</h2>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs text-zinc-400 mb-1">Логін</label>
            <input type="text" value={login} onChange={e => setLogin(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-2 text-white" />
          </div>
          <div>
            <label className="block text-xs text-zinc-400 mb-1">Пароль</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-black border border-white/10 rounded-lg px-4 py-2 text-white" />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <button type="submit" className="w-full bg-red-600 text-white font-bold py-3 rounded-lg hover:bg-red-700 transition-colors">Увійти</button>
        </form>
        <div className="mt-6 pt-6 border-t border-white/5">
          <button 
            onClick={() => navigate('/')}
            className="w-full text-zinc-500 hover:text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
          >
            ← На головну
          </button>
        </div>
      </div>
    </div>
  );
};

export const AdminPage = () => {
  const [activeTab, setActiveTab] = useState('content');
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem('admin_token');
      if (!token) {
        navigate('/login');
        return;
      }
      const res = await fetch('/api/check-auth', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) {
        localStorage.removeItem('admin_token');
        navigate('/login');
      }
    };
    checkAuth();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-black text-white flex">
      {/* Sidebar */}
      <div className="w-64 bg-zinc-950 border-r border-white/5 p-6 flex flex-col">
        <div className="text-xl font-black text-red-600 uppercase tracking-widest mb-10">BBD Admin</div>
        
        <nav className="space-y-2 flex-grow">
          <button 
            onClick={() => setActiveTab('content')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'content' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'}`}
          >
            <Settings size={18} />
            <span className="font-medium">Контент сайту</span>
          </button>
          <button 
            onClick={() => setActiveTab('coaches')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'coaches' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'}`}
          >
            <Users size={18} />
            <span className="font-medium">Тренери</span>
          </button>
          <button 
            onClick={() => setActiveTab('locations')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'locations' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'}`}
          >
            <MapPin size={18} />
            <span className="font-medium">Локації</span>
          </button>
          <button 
            onClick={() => setActiveTab('schedule')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'schedule' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'}`}
          >
            <Clock size={18} />
            <span className="font-medium">Розклад</span>
          </button>
          <button 
            onClick={() => setActiveTab('leads')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'leads' ? 'bg-red-600 text-white' : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'}`}
          >
            <MessageSquare size={18} />
            <span className="font-medium">Заявки</span>
          </button>
        </nav>

        <button 
          onClick={() => {
            localStorage.removeItem('admin_token');
            navigate('/');
          }}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-zinc-500 hover:bg-zinc-900 hover:text-white transition-colors mt-auto"
        >
          <LogOut size={18} />
          <span className="font-medium">Вийти на сайт</span>
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-10 overflow-y-auto">
        {activeTab === 'content' && <ContentEditor />}
        {activeTab === 'leads' && <LeadsViewer />}
        {activeTab === 'coaches' && <CoachesEditor />}
        {activeTab === 'locations' && <LocationsEditor />}
        {activeTab === 'schedule' && <ScheduleEditor />}
      </div>
    </div>
  );
};

const ContentEditor = () => {
  const [content, setContent] = useState<Record<string, string>>({});
  const [dirtyFields, setDirtyFields] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    fetch(`/api/content?t=${Date.now()}`).then(res => res.json()).then(setContent);
  }, []);

  const handleChange = (key: string, value: string) => {
    setContent(prev => ({ ...prev, [key]: value }));
    setDirtyFields(prev => new Set(prev).add(key));
  };

  const handleSave = async (delta?: Record<string, string>) => {
    setSaving(true);
    try {
      const token = localStorage.getItem('admin_token');
      
      // If delta is provided (e.g. image upload), use it. 
      // Otherwise, collect all dirty fields from the current content state.
      const payload: Record<string, string> = delta || {};
      if (!delta) {
        dirtyFields.forEach(key => {
          payload[key] = content[key];
        });
      }

      if (Object.keys(payload).length === 0) {
        setSaving(false);
        return;
      }

      const response = await fetch('/api/content', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
        throw new Error(errorData.error || `Server error: ${response.status}`);
      }
      
      setDirtyFields(new Set());
      console.log('Save successful');
    } catch (e: any) {
      console.error('Save failed', e);
      alert(`Помилка збереження: ${e.message}. Якщо ви вставляєте скрипт, спробуйте видалити теги <script> та <noscript> і залишити лише чистий код.`);
    }
    setSaving(false);
  };

  const handleImageUpload = (key: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      alert('Файл занадто великий. Максимальний розмір - 15 МБ.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const img = new Image();
      img.onload = async () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Max dimensions to keep file size reasonable
        const MAX_WIDTH = 1920;
        const MAX_HEIGHT = 1080;

        if (width > MAX_WIDTH) {
          height *= MAX_WIDTH / width;
          width = MAX_WIDTH;
        }
        if (height > MAX_HEIGHT) {
          width *= MAX_HEIGHT / height;
          height = MAX_HEIGHT;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);

        // Compress as JPEG with 0.7 quality
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
        
        setContent(prev => ({ ...prev, [key]: compressedBase64 }));
        await handleSave({ [key]: compressedBase64 });
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  const sections = [
    {
      id: 'hero',
      title: '1. Головний екран',
      fields: [
        { key: 'hero_bg', label: 'Фонове зображення (Головне)', type: 'image' },
        { key: 'hero_title', label: 'Заголовок', type: 'textarea' },
        { key: 'hero_subtitle', label: 'Підзаголовок', type: 'textarea' },
      ]
    },
    {
      id: 'transformation',
      title: '2. Трансформація',
      fields: [
        { key: 'transformation_bg', label: 'Фонове зображення блоку', type: 'image' },
        { key: 'transformation_title', label: 'Заголовок', type: 'text' },
        { key: 'transformation_subtitle', label: 'Підзаголовок', type: 'textarea' },
      ]
    },
    {
      id: 'how',
      title: '3. Як це працює',
      fields: [
        { key: 'how_bg', label: 'Фонове зображення блоку', type: 'image' },
      ]
    },
    {
      id: 'about',
      title: '4. Про нас',
      fields: [
        { key: 'about_image', label: 'Фонове зображення розділу', type: 'image' },
        { key: 'about_title', label: 'Заголовок', type: 'text' },
        { key: 'about_text', label: 'Основний текст (можна використовувати <br />)', type: 'textarea' },
      ]
    },
    {
      id: 'directions',
      title: '5. Напрями',
      fields: [
        { key: 'directions_bg', label: 'Фонове зображення', type: 'image' },
        { key: 'directions_title', label: 'Заголовок', type: 'text' },
        { key: 'directions_subtitle', label: 'Підзаголовок', type: 'textarea' },
      ]
    },
    {
      id: 'results',
      title: '6. Результати',
      fields: [
        { key: 'results_bg', label: 'Фонове зображення', type: 'image' },
        { key: 'results_image', label: 'Центральне фото (Системна підготовка)', type: 'image' },
        { key: 'results_image_title', label: 'Заголовок на фото', type: 'text' },
        { key: 'results_image_subtitle', label: 'Підзаголовок на фото', type: 'text' },
        { key: 'results_title', label: 'Заголовок секції', type: 'text' },
      ]
    },
    {
      id: 'schedule',
      title: '7. Розклад (Фон)',
      fields: [
        { key: 'schedule_bg', label: 'Фонове зображення блоку', type: 'image' },
      ]
    },
    {
      id: 'reviews',
      title: '8. Відгуки',
      fields: [
        { key: 'reviews_bg', label: 'Фонове зображення', type: 'image' },
      ]
    },
    {
      id: 'faq',
      title: '9. FAQ',
      fields: [
        { key: 'faq_bg', label: 'Фонове зображення', type: 'image' },
      ]
    },
    {
      id: 'contacts',
      title: '10. Контакти',
      fields: [
        { key: 'contact_bg', label: 'Фонове зображення', type: 'image' },
        { key: 'contact_title', label: 'Заголовок форми', type: 'text' },
        { key: 'social_instagram', label: 'Instagram Link', type: 'text' },
        { key: 'social_facebook', label: 'Facebook Link', type: 'text' },
      ]
    },
    {
      id: 'analytics',
      title: 'Аналітика',
      fields: [
        { key: 'google_pixel_code', label: 'Google Pixel Code', type: 'textarea' },
        { key: 'meta_pixel_code', label: 'Meta Pixel Code', type: 'textarea' },
      ]
    }
  ];

  const activeFields = sections.find(s => s.id === activeSection)?.fields || [];

  return (
    <div className="max-w-4xl">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold">Конструктор сайту</h2>
        <button 
          onClick={() => handleSave()}
          disabled={saving}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-xl font-bold transition-colors disabled:opacity-50"
        >
          <Save size={18} />
          {saving ? 'Збереження...' : 'Зберегти зміни'}
        </button>
      </div>

      <div className="flex gap-8">
        {/* Section Tabs */}
        <div className="w-64 shrink-0 space-y-2">
          {sections.map(section => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`w-full text-left px-4 py-3 rounded-xl font-bold transition-colors ${activeSection === section.id ? 'bg-zinc-800 text-white border border-white/10' : 'text-zinc-500 hover:bg-zinc-900 hover:text-white'}`}
            >
              {section.title}
            </button>
          ))}
        </div>

        {/* Fields */}
        <div className="flex-1 space-y-6">
          {activeFields.map(field => (
            <div key={field.key} className="bg-zinc-900 p-6 rounded-2xl border border-white/5">
              <label className="block text-sm font-bold text-zinc-300 mb-2">{field.label}</label>
              {field.type === 'image' ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <label className="flex-1 flex items-center justify-center gap-3 bg-red-600/10 hover:bg-red-600/20 text-red-500 border-2 border-dashed border-red-600/30 rounded-2xl p-8 cursor-pointer transition-all group">
                      <ImageIcon size={32} className="group-hover:scale-110 transition-transform" />
                      <div className="text-left">
                        <p className="font-bold uppercase tracking-widest text-xs">Завантажити нове фото</p>
                        <p className="text-[10px] opacity-60">PNG, JPG до 15MB</p>
                      </div>
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(field.key, e)} />
                    </label>
                  </div>
                  {content[field.key] && (
                    <div className="relative rounded-2xl overflow-hidden border border-white/10 aspect-video bg-black">
                      <img src={content[field.key]} alt="Preview" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-white/80">Поточне зображення</span>
                      </div>
                    </div>
                  )}
                </div>
              ) : field.type === 'textarea' ? (
                <textarea 
                  value={content[field.key] || ''} 
                  onChange={e => handleChange(field.key, e.target.value)}
                  className="w-full bg-black border border-white/10 rounded-xl p-4 text-white min-h-[100px] focus:border-red-600 outline-none transition-colors"
                />
              ) : (
                <input 
                  type="text" 
                  value={content[field.key] || ''} 
                  onChange={e => handleChange(field.key, e.target.value)}
                  className="w-full bg-black border border-white/10 rounded-xl p-4 text-white focus:border-red-600 outline-none transition-colors"
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const CoachesEditor = () => {
  const [coaches, setCoaches] = useState<any[]>([]);
  const [editingCoach, setEditingCoach] = useState<any | null>(null);

  const fetchCoaches = () => {
    fetch('/api/coaches')
      .then(res => res.json())
      .then(data => setCoaches(Array.isArray(data) ? data : []))
      .catch(() => setCoaches([]));
  };

  useEffect(() => {
    fetchCoaches();
  }, []);

  const handleSaveCoach = async (coach: any) => {
    try {
      const token = localStorage.getItem('admin_token');
      if (coach.id) {
        await fetch(`/api/coaches/${coach.id}`, {
          method: 'PUT',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(coach)
        });
      } else {
        await fetch('/api/coaches', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(coach)
        });
      }
      setEditingCoach(null);
      fetchCoaches();
    } catch (e) {
      alert('Помилка збереження');
    }
  };

  const handleDeleteCoach = async (id: number) => {
    if (!confirm('Ви впевнені, що хочете видалити цього тренера?')) return;
    try {
      const token = localStorage.getItem('admin_token');
      await fetch(`/api/coaches/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchCoaches();
    } catch (e) {
      alert('Помилка видалення');
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>, coachId: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      alert('Файл занадто великий. Максимальний розмір - 10 МБ.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      if (coachId) {
        const token = localStorage.getItem('admin_token');
        await fetch(`/api/coaches/${coachId}/photo`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ photo: base64 })
        });
        fetchCoaches();
      }
      if (editingCoach && (editingCoach.id === coachId || !editingCoach.id)) {
        setEditingCoach({ ...editingCoach, photo: base64 });
      }
    };
    reader.readAsDataURL(file);
  };

  if (editingCoach) {
    return (
      <div className="max-w-3xl">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Редагування тренера</h2>
          <div className="flex gap-4">
            <button 
              onClick={() => setEditingCoach(null)}
              className="px-6 py-2 rounded-xl font-bold border border-white/10 hover:bg-white/5 transition-colors"
            >
              Скасувати
            </button>
            <button 
              onClick={() => handleSaveCoach(editingCoach)}
              className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-xl font-bold transition-colors"
            >
              <Save size={18} />
              Зберегти
            </button>
          </div>
        </div>

        <div className="bg-zinc-900 p-8 rounded-[2rem] border border-white/5 space-y-6">
          <div className="flex gap-8">
            <div className="w-1/3">
              <div className="aspect-[3/4] rounded-2xl overflow-hidden border border-white/10 relative group bg-black">
                {editingCoach.photo ? (
                  <img src={editingCoach.photo} alt={editingCoach.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-600">
                    <ImageIcon size={48} />
                  </div>
                )}
                <label className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer">
                  <ImageIcon size={32} className="mb-2" />
                  <span className="text-sm font-bold">Завантажити фото</span>
                  <input type="file" accept="image/*" className="hidden" onChange={e => handlePhotoUpload(e, editingCoach.id)} />
                </label>
              </div>
            </div>
            
            <div className="w-2/3 space-y-4">
              <div>
                <label className="block text-sm font-bold text-zinc-300 mb-2">Ім'я</label>
                <input 
                  type="text" 
                  value={editingCoach.name} 
                  onChange={e => setEditingCoach({...editingCoach, name: e.target.value})}
                  className="w-full bg-black border border-white/10 rounded-xl p-4 text-white focus:border-red-600 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-zinc-300 mb-2">Посада / Звання</label>
                <input 
                  type="text" 
                  value={editingCoach.role} 
                  onChange={e => setEditingCoach({...editingCoach, role: e.target.value})}
                  className="w-full bg-black border border-white/10 rounded-xl p-4 text-white focus:border-red-600 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-zinc-300 mb-2">Біографія</label>
                <textarea 
                  value={editingCoach.bio} 
                  onChange={e => setEditingCoach({...editingCoach, bio: e.target.value})}
                  className="w-full bg-black border border-white/10 rounded-xl p-4 text-white min-h-[100px] focus:border-red-600 outline-none"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-zinc-300 mb-2">Досягнення (по одному на рядок)</label>
            <textarea 
              value={(editingCoach.achievements || []).join('\n')} 
              onChange={e => setEditingCoach({...editingCoach, achievements: e.target.value.split('\n').filter(Boolean)})}
              className="w-full bg-black border border-white/10 rounded-xl p-4 text-white min-h-[150px] focus:border-red-600 outline-none"
              placeholder="Майстер спорту&#10;Чемпіон України"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold">Тренери</h2>
        <button 
          onClick={() => setEditingCoach({ name: '', role: '', bio: '', achievements: [], photo: '' })}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-xl font-bold transition-colors"
        >
          <Plus size={18} />
          Додати тренера
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {Array.isArray(coaches) && coaches.map(coach => (
          <div key={coach.id} className="bg-zinc-900 p-6 rounded-[2rem] border border-white/5 flex flex-col">
            <div className="aspect-[4/3] rounded-xl overflow-hidden mb-6 bg-black relative group">
              {coach.photo ? (
                <img src={coach.photo} alt={coach.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-zinc-600">
                  <ImageIcon size={32} />
                </div>
              )}
              <button 
                onClick={() => handleDeleteCoach(coach.id)}
                className="absolute top-4 right-4 p-2 bg-black/60 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
              >
                <Trash2 size={18} />
              </button>
            </div>
            <h3 className="text-xl font-bold mb-1">{coach.name}</h3>
            <p className="text-sm text-red-500 mb-4">{coach.role}</p>
            <button 
              onClick={() => setEditingCoach(coach)}
              className="mt-auto w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl font-bold transition-colors"
            >
              Редагувати
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

const LocationsEditor = () => {
  const [locations, setLocations] = useState<any[]>([]);
  const [editingLocation, setEditingLocation] = useState<any | null>(null);

  const fetchLocations = () => {
    fetch('/api/locations')
      .then(res => res.json())
      .then(data => setLocations(Array.isArray(data) ? data : []))
      .catch(() => setLocations([]));
  };

  useEffect(() => {
    fetchLocations();
  }, []);

  const handleSaveLocation = async (location: any) => {
    try {
      const token = localStorage.getItem('admin_token');
      const method = location.id ? 'PUT' : 'POST';
      const url = location.id ? `/api/locations/${location.id}` : '/api/locations';
      
      await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(location)
      });
      setEditingLocation(null);
      fetchLocations();
    } catch (e) {
      alert('Помилка збереження');
    }
  };

  const handleDeleteLocation = async (id: number) => {
    if (!confirm('Ви впевнені, що хочете видалити цю локацію?')) return;
    try {
      const token = localStorage.getItem('admin_token');
      await fetch(`/api/locations/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchLocations();
    } catch (e) {
      alert('Помилка видалення');
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold">Локації</h2>
        <button 
          onClick={() => setEditingLocation({ name: '', address: '', map_link: '', order_index: 0 })}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-xl font-bold transition-colors"
        >
          <Plus size={18} />
          Додати локацію
        </button>
      </div>

      {editingLocation && (
        <div className="bg-zinc-900 p-8 rounded-2xl border border-white/5 mb-8 space-y-4">
          <h3 className="text-xl font-bold mb-4">{editingLocation.id ? 'Редагувати' : 'Нова'} локація</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Назва</label>
              <input 
                type="text" 
                value={editingLocation.name} 
                onChange={e => setEditingLocation({...editingLocation, name: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white focus:border-red-600 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Адреса</label>
              <input 
                type="text" 
                value={editingLocation.address} 
                onChange={e => setEditingLocation({...editingLocation, address: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white focus:border-red-600 outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-bold text-zinc-300 mb-2">Посилання на Google Maps</label>
            <input 
              type="text" 
              value={editingLocation.map_link} 
              onChange={e => setEditingLocation({...editingLocation, map_link: e.target.value})}
              className="w-full bg-black border border-white/10 rounded-xl p-4 text-white focus:border-red-600 outline-none"
            />
          </div>
          <div className="flex gap-4 pt-4">
            <button 
              onClick={() => handleSaveLocation(editingLocation)}
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-bold transition-colors"
            >
              Зберегти
            </button>
            <button 
              onClick={() => setEditingLocation(null)}
              className="bg-zinc-800 hover:bg-zinc-700 text-white px-8 py-3 rounded-xl font-bold transition-colors"
            >
              Скасувати
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4">
        {Array.isArray(locations) && locations.map(loc => (
          <div key={loc.id} className="bg-zinc-900 p-6 rounded-2xl border border-white/5 flex justify-between items-center">
            <div>
              <h3 className="text-xl font-bold">{loc.name}</h3>
              <p className="text-zinc-400">{loc.address}</p>
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setEditingLocation(loc)}
                className="p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
              >
                Редагувати
              </button>
              <button 
                onClick={() => handleDeleteLocation(loc.id)}
                className="p-3 bg-red-600/10 hover:bg-red-600/20 text-red-500 rounded-xl transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const ScheduleEditor = () => {
  const [schedule, setSchedule] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [coaches, setCoaches] = useState<any[]>([]);
  const [editingEntry, setEditingEntry] = useState<any | null>(null);

  const fetchData = async () => {
    try {
      const [sRes, lRes, cRes] = await Promise.all([
        fetch('/api/schedule'),
        fetch('/api/locations'),
        fetch('/api/coaches')
      ]);
      const sData = await sRes.json();
      const lData = await lRes.json();
      const cData = await cRes.json();
      
      setSchedule(Array.isArray(sData) ? sData : []);
      setLocations(Array.isArray(lData) ? lData : []);
      setCoaches(Array.isArray(cData) ? cData : []);
    } catch (e) {
      setSchedule([]);
      setLocations([]);
      setCoaches([]);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveEntry = async (entry: any) => {
    try {
      const token = localStorage.getItem('admin_token');
      const method = entry.id ? 'PUT' : 'POST';
      const url = entry.id ? `/api/schedule/${entry.id}` : '/api/schedule';
      
      await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(entry)
      });
      setEditingEntry(null);
      fetchData();
    } catch (e) {
      alert('Помилка збереження');
    }
  };

  const handleDeleteEntry = async (id: number) => {
    if (!confirm('Ви впевнені?')) return;
    try {
      const token = localStorage.getItem('admin_token');
      await fetch(`/api/schedule/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchData();
    } catch (e) {
      alert('Помилка видалення');
    }
  };

  const days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд"];

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold">Розклад занять</h2>
        <button 
          onClick={() => setEditingEntry({ location_id: locations[0]?.id, coach_id: coaches[0]?.id, day_of_week: 'Пн', start_time: '16:00', end_time: '17:30', group_name: '', order_index: 0 })}
          className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-xl font-bold transition-colors"
        >
          <Plus size={18} />
          Додати заняття
        </button>
      </div>

      {editingEntry && (
        <div className="bg-zinc-900 p-8 rounded-2xl border border-white/5 mb-8 space-y-4">
          <h3 className="text-xl font-bold mb-4">{editingEntry.id ? 'Редагувати' : 'Нове'} заняття</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Локація</label>
              <select 
                value={editingEntry.location_id} 
                onChange={e => setEditingEntry({...editingEntry, location_id: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white outline-none"
              >
                {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Тренер</label>
              <select 
                value={editingEntry.coach_id} 
                onChange={e => setEditingEntry({...editingEntry, coach_id: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white outline-none"
              >
                {coaches.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">День тижня</label>
              <select 
                value={editingEntry.day_of_week} 
                onChange={e => setEditingEntry({...editingEntry, day_of_week: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white outline-none"
              >
                {days.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Група</label>
              <input 
                type="text" 
                value={editingEntry.group_name} 
                onChange={e => setEditingEntry({...editingEntry, group_name: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white outline-none"
                placeholder="Молодша група"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Ціна (тільки число)</label>
              <div className="relative">
                <input 
                  type="text" 
                  value={editingEntry.price || ''} 
                  onChange={e => setEditingEntry({...editingEntry, price: e.target.value})}
                  className="w-full bg-black border border-white/10 rounded-xl p-4 pr-20 text-white outline-none"
                  placeholder="2500"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 text-xs font-bold uppercase">грн/міс</div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Час початку</label>
              <input 
                type="text" 
                value={editingEntry.start_time} 
                onChange={e => setEditingEntry({...editingEntry, start_time: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white outline-none"
                placeholder="16:00"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-zinc-300 mb-2">Час завершення</label>
              <input 
                type="text" 
                value={editingEntry.end_time} 
                onChange={e => setEditingEntry({...editingEntry, end_time: e.target.value})}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white outline-none"
                placeholder="17:30"
              />
            </div>
          </div>
          <div className="flex gap-4 pt-4">
            <button 
              onClick={() => handleSaveEntry(editingEntry)}
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-bold transition-colors"
            >
              Зберегти
            </button>
            <button 
              onClick={() => setEditingEntry(null)}
              className="bg-zinc-800 hover:bg-zinc-700 text-white px-8 py-3 rounded-xl font-bold transition-colors"
            >
              Скасувати
            </button>
          </div>
        </div>
      )}

      <div className="space-y-8">
        {locations.map(loc => {
          const locSchedule = schedule.filter(s => s.location_id === loc.id);
          if (locSchedule.length === 0) return null;
          
          return (
            <div key={loc.id} className="bg-zinc-900 rounded-2xl border border-white/5 overflow-hidden">
              <div className="bg-black/50 p-6 border-b border-white/5">
                <h3 className="text-xl font-bold text-red-500">{loc.name}</h3>
                <p className="text-sm text-zinc-500">{loc.address}</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-xs font-bold text-zinc-500 uppercase tracking-widest border-b border-white/5">
                      <th className="p-4">День</th>
                      <th className="p-4">Час</th>
                      <th className="p-4">Група</th>
                      <th className="p-4">Ціна</th>
                      <th className="p-4">Тренер</th>
                      <th className="p-4 text-right">Дії</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {locSchedule.map(entry => (
                      <tr key={entry.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4 font-bold">{entry.day_of_week}</td>
                        <td className="p-4 text-zinc-300">{entry.start_time} - {entry.end_time}</td>
                        <td className="p-4">{entry.group_name}</td>
                        <td className="p-4 text-red-500 font-bold">{entry.price ? `${entry.price} грн/міс` : '—'}</td>
                        <td className="p-4 text-sm text-zinc-400">{entry.coach_name}</td>
                        <td className="p-4 text-right">
                          <div className="flex justify-end gap-2">
                            <button onClick={() => setEditingEntry(entry)} className="p-2 hover:text-red-500 transition-colors">
                              Редагувати
                            </button>
                            <button onClick={() => handleDeleteEntry(entry.id)} className="p-2 hover:text-red-500 transition-colors">
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const LeadsViewer = () => {
  const [leads, setLeads] = useState<any[]>([]);

  const fetchLeads = () => {
    const token = localStorage.getItem('admin_token');
    fetch('/api/leads', {
      headers: { 'Authorization': `Bearer ${token}` }
    }).then(res => res.json()).then(setLeads);
  };

  useEffect(() => {
    fetchLeads();
  }, []);

  const handleDelete = async (id: number) => {
    if (!confirm('Ви впевнені, що хочете видалити цю заявку?')) return;
    
    try {
      const token = localStorage.getItem('admin_token');
      const res = await fetch(`/api/leads/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (res.ok) {
        fetchLeads();
      } else {
        alert('Помилка видалення заявки');
      }
    } catch (e) {
      alert('Помилка видалення заявки');
    }
  };

  return (
    <div>
      <h2 className="text-3xl font-bold mb-8">Заявки з сайту</h2>
      
      <div className="bg-zinc-900 rounded-[2rem] border border-white/5 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-black/50 border-b border-white/5">
            <tr>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Дата</th>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Ім'я</th>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Телефон</th>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Локація</th>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Група</th>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Статус</th>
              <th className="p-6 text-xs font-bold text-zinc-500 uppercase tracking-widest">Дії</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {leads.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-zinc-500">Заявок поки немає</td>
              </tr>
            ) : (
              leads.map(lead => (
                <tr key={lead.id} className="hover:bg-white/5 transition-colors">
                  <td className="p-6 text-sm text-zinc-400">{new Date(lead.created_at).toLocaleString('uk-UA')}</td>
                  <td className="p-6 font-bold">{lead.name}</td>
                  <td className="p-6 font-mono text-red-400">{lead.phone}</td>
                  <td className="p-6 text-sm">{lead.location || 'Не вказано'}</td>
                  <td className="p-6 text-sm">{lead.age_group}</td>
                  <td className="p-6">
                    <span className="px-3 py-1 bg-zinc-800 text-xs font-bold rounded-full uppercase tracking-widest">
                      {lead.status === 'new' ? 'Нова' : lead.status}
                    </span>
                  </td>
                  <td className="p-6">
                    <button 
                      onClick={() => handleDelete(lead.id)}
                      className="p-2 text-zinc-500 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                      title="Видалити заявку"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
