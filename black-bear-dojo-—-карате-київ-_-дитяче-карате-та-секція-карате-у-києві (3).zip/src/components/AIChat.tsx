import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

const systemInstruction = `Ти — онлайн-помічник та менеджер з продажу клубу кіокушинкай карате "Black Bear Dojo" у Києві.
Твоя мета: привітатися, відповісти на запитання користувача, спираючись ТІЛЬКИ на факти нижче, і м'яко підвести його до запису на БЕЗКОШТОВНЕ пробне тренування.

ФАКТИ ПРО КЛУБ:
- Назва: Black Bear Dojo
- Локації та Тренери: 
  1. Шулявка (вул. Сім'ї Бродських, 31/33). Тренер: Ігор Котляревський (095 475 65 00).
  2. Поділ / Виноградар (вул. Віктора Некрасова, 1-3). Тренер: Олег Крамаренко (095 568 06 04).
- Вікові групи: 4-7 років, 7-12 років, 12+ років.
- Вартість: 2500 грн/місяць.
- Перше (пробне) тренування — БЕЗКОШТОВНЕ.
- Що дає карате: дисципліна, фізичний розвиток, впевненість, самозахист, відрив від гаджетів.

ПРАВИЛА СПІЛКУВАННЯ:
1. Будь ввічливим, професійним та лаконічним (не пиши довгі тексти, максимум 2-3 коротких речення).
2. Використовуй українську мову.
3. Якщо людина виявляє бажання записатися на пробне тренування, ти ПОВИНЕН:
   - Запитати, яка локація їй зручніша (Шулявка чи Некрасова), якщо вона ще не вказала.
   - Якщо локація відома, надати ім'я та телефон відповідного тренера.
   - ОБОВ'ЯЗКОВО додати в кінці свого повідомлення спеціальний код: [SIGNUP_BUTTON]
4. НЕ вигадуй інформацію. Якщо чогось немає у фактах, скажи, що краще уточнити це у тренера по телефону.
5. Завжди намагайся закінчити повідомлення питанням, яке спонукає до діалогу (наприклад: "Скільки років вашій дитині?", "Вам зручніше локація на Шулявці чи на Некрасова?").`;

type Message = { id: string; role: 'user' | 'model'; text: string };

export const AIChat = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'model', text: 'Вітаю! 👋 Я онлайн-помічник Black Bear Dojo. Бачу, ви цікавитесь тренуваннями. Підказати вам розклад чи деталі щодо пробного заняття?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<any>(null);

  // Auto-open logic based on engagement
  useEffect(() => {
    // Open after 15 seconds of dwelling
    const timer = setTimeout(() => {
      if (!isOpen && !hasInteracted) {
        setIsOpen(true);
      }
    }, 15000);

    // Open after scrolling 40% of the page
    const handleScroll = () => {
      const scrolled = window.scrollY;
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (maxScroll > 0 && scrolled / maxScroll > 0.4 && !isOpen && !hasInteracted) {
        setIsOpen(true);
        window.removeEventListener('scroll', handleScroll);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('scroll', handleScroll);
    };
  }, [isOpen, hasInteracted]);

  // Initialize Gemini API
  useEffect(() => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.error("Gemini API key is missing");
      return;
    }
    try {
      const ai = new GoogleGenAI({ apiKey });
      chatRef.current = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });
    } catch (e) {
      console.error("Failed to initialize Gemini", e);
    }
  }, []);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping, isOpen]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || !chatRef.current) return;

    const userText = input.trim();
    setInput('');
    setHasInteracted(true);
    
    const newUserMsg: Message = { id: Date.now().toString(), role: 'user', text: userText };
    setMessages(prev => [...prev, newUserMsg]);
    setIsTyping(true);

    try {
      const response = await chatRef.current.sendMessage({ message: userText });
      const modelMsg: Message = { id: (Date.now() + 1).toString(), role: 'model', text: response.text };
      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: 'Вибачте, сталася помилка з\'єднання. Будь ласка, зателефонуйте нам або залиште заявку у формі на сайті.' }]);
    } finally {
      setIsTyping(false);
    }
  };

  const renderMessageText = (text: string) => {
    if (text.includes('[SIGNUP_BUTTON]')) {
      const cleanText = text.replace('[SIGNUP_BUTTON]', '').trim();
      return (
        <div className="space-y-3">
          <div>{cleanText}</div>
          <button 
            onClick={() => {
              setIsOpen(false);
              document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="w-full bg-red-600 text-white text-xs font-bold uppercase tracking-widest py-2.5 rounded-lg hover:bg-red-500 transition-colors shadow-[0_4px_12px_rgba(220,38,38,0.3)] flex items-center justify-center gap-2"
          >
            Записатися на пробне
          </button>
        </div>
      );
    }
    return text;
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="bg-zinc-950 border border-white/10 rounded-2xl shadow-2xl w-[350px] max-w-[calc(100vw-3rem)] h-[500px] max-h-[calc(100vh-8rem)] flex flex-col mb-4 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-zinc-900 border-b border-white/10 p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                  <Bot size={18} className="text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-sm uppercase tracking-wider">Помічник Dojo</h3>
                  <p className="text-red-500 text-[10px] uppercase tracking-widest font-bold">Онлайн</p>
                </div>
              </div>
              <button 
                onClick={() => { setIsOpen(false); setHasInteracted(true); }}
                className="text-zinc-400 hover:text-white transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-black/50">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-zinc-800 text-white rounded-br-sm' 
                        : 'bg-red-950/50 border border-red-900/30 text-zinc-200 rounded-bl-sm'
                    }`}
                  >
                    {renderMessageText(msg.text)}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-red-950/50 border border-red-900/30 rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-1">
                    <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0 }} className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                    <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                    <motion.div animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }} className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-3 bg-zinc-900 border-t border-white/10 flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Напишіть повідомлення..."
                className="flex-1 bg-black border border-white/10 rounded-full px-4 py-2.5 text-sm text-white focus:outline-none focus:border-red-500/50 transition-colors"
              />
              <button 
                type="submit"
                disabled={!input.trim() || isTyping}
                className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-red-500 transition-colors shrink-0"
              >
                <Send size={16} className="ml-0.5" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Toggle Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => { setIsOpen(!isOpen); setHasInteracted(true); }}
        className="w-14 h-14 bg-red-600 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(220,38,38,0.4)] hover:shadow-[0_0_40px_rgba(220,38,38,0.6)] transition-shadow relative"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X size={24} className="text-white" />
            </motion.div>
          ) : (
            <motion.div key="chat" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <MessageCircle size={24} className="text-white" />
            </motion.div>
          )}
        </AnimatePresence>
        {!isOpen && !hasInteracted && (
          <motion.div 
            initial={{ scale: 0 }} 
            animate={{ scale: 1 }} 
            className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full border-2 border-zinc-950"
          />
        )}
      </motion.button>
    </div>
  );
};
